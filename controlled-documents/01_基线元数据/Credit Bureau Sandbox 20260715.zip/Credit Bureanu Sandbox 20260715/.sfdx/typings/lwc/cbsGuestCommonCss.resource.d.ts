declare module "@salesforce/resourceUrl/cbsGuestCommonCss" {
    var cbsGuestCommonCss: string;
    export default cbsGuestCommonCss;
}