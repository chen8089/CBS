declare module "@salesforce/resourceUrl/cbsAssets" {
    var cbsAssets: string;
    export default cbsAssets;
}