declare module "@salesforce/resourceUrl/LOGO" {
    var LOGO: string;
    export default LOGO;
}