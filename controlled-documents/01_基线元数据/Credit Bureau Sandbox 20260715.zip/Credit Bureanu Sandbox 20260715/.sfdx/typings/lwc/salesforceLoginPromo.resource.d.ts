declare module "@salesforce/resourceUrl/salesforceLoginPromo" {
    var salesforceLoginPromo: string;
    export default salesforceLoginPromo;
}