declare module "@salesforce/resourceUrl/nonSingpassPhotoGuide" {
    var nonSingpassPhotoGuide: string;
    export default nonSingpassPhotoGuide;
}