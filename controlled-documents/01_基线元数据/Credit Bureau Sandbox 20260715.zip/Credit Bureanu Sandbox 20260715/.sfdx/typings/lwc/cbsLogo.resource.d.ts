declare module "@salesforce/resourceUrl/cbsLogo" {
    var cbsLogo: string;
    export default cbsLogo;
}