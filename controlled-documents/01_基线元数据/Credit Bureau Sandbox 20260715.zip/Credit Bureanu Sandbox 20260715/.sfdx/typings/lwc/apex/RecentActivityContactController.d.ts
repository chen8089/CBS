declare module "@salesforce/apex/RecentActivityContactController.getRecentActivities" {
  export default function getRecentActivities(param: {maxItems: any}): Promise<any>;
}
declare module "@salesforce/apex/RecentActivityContactController.getRecentActivitiesByRecordId" {
  export default function getRecentActivitiesByRecordId(param: {recordId: any, maxItems: any}): Promise<any>;
}
declare module "@salesforce/apex/RecentActivityContactController.getRecentActivitiesWithDebug" {
  export default function getRecentActivitiesWithDebug(param: {maxItems: any}): Promise<any>;
}
