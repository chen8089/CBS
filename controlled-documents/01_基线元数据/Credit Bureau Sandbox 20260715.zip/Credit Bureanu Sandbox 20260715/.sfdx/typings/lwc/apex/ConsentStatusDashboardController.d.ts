declare module "@salesforce/apex/ConsentStatusDashboardController.getConsentSummary" {
  export default function getConsentSummary(): Promise<any>;
}
declare module "@salesforce/apex/ConsentStatusDashboardController.getConsents" {
  export default function getConsents(param: {statusFilter: any, searchKey: any, sortBy: any, sortDirection: any, filters: any}): Promise<any>;
}
