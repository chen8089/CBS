declare module "@salesforce/apex/ExceptionDashboardController.getExceptionSummary" {
  export default function getExceptionSummary(): Promise<any>;
}
declare module "@salesforce/apex/ExceptionDashboardController.getExceptions" {
  export default function getExceptions(param: {statusFilter: any, searchKey: any, sortBy: any, sortDirection: any, filters: any}): Promise<any>;
}
