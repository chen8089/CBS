declare module "@salesforce/apex/CbsForgotPasswordController.resetPassword" {
  export default function resetPassword(param: {username: any}): Promise<any>;
}
