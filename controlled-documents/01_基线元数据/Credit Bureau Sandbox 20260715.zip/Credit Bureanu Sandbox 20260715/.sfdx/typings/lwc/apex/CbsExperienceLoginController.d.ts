declare module "@salesforce/apex/CbsExperienceLoginController.login" {
  export default function login(param: {username: any, password: any, rememberMe: any, startUrl: any}): Promise<any>;
}
declare module "@salesforce/apex/CbsExperienceLoginController.resetPassword" {
  export default function resetPassword(param: {username: any}): Promise<any>;
}
