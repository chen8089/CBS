declare module "@salesforce/apex/RecentActivityFeedDebugController.getContactDebugInfo" {
  export default function getContactDebugInfo(param: {maxRecords: any}): Promise<any>;
}
