declare module "@salesforce/apex/BatchUploadDashboardController.getBatchSummary" {
  export default function getBatchSummary(): Promise<any>;
}
declare module "@salesforce/apex/BatchUploadDashboardController.getBatches" {
  export default function getBatches(param: {statusFilter: any, searchKey: any, sortBy: any, sortDirection: any, filters: any}): Promise<any>;
}
