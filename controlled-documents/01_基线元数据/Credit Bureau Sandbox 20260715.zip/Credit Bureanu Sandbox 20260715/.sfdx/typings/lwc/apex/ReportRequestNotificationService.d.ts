declare module "@salesforce/apex/ReportRequestNotificationService.markSubmitted" {
  export default function markSubmitted(param: {caseId: any, reportRequestItemIds: any}): Promise<any>;
}
declare module "@salesforce/apex/ReportRequestNotificationService.completeAndNotify" {
  export default function completeAndNotify(param: {request: any}): Promise<any>;
}
