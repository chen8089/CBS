declare module "@salesforce/apex/CaseOfflineProcessingDashboardController.getReportSummary" {
  export default function getReportSummary(): Promise<any>;
}
declare module "@salesforce/apex/CaseOfflineProcessingDashboardController.getReports" {
  export default function getReports(param: {statusFilter: any, searchKey: any, sortBy: any, sortDirection: any, filters: any}): Promise<any>;
}
