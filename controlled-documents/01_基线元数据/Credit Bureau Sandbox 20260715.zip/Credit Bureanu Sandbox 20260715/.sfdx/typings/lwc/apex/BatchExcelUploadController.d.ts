declare module "@salesforce/apex/BatchExcelUploadController.getCurrentClientAccountId" {
  export default function getCurrentClientAccountId(): Promise<any>;
}
declare module "@salesforce/apex/BatchExcelUploadController.createBatchAndContacts" {
  export default function createBatchAndContacts(param: {batchName: any, fileName: any, rowsJson: any}): Promise<any>;
}
declare module "@salesforce/apex/BatchExcelUploadController.validateAndUpload" {
  export default function validateAndUpload(param: {batchName: any, fileName: any, rowsJson: any, headersJson: any, fileSizeBytes: any, fileBodyBase64: any, fileMimeType: any}): Promise<any>;
}
declare module "@salesforce/apex/BatchExcelUploadController.uploadBatchContacts" {
  export default function uploadBatchContacts(param: {rows: any, batchName: any, fileName: any}): Promise<any>;
}
