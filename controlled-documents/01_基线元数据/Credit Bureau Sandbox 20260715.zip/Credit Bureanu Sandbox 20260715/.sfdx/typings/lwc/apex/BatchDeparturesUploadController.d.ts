declare module "@salesforce/apex/BatchDeparturesUploadController.validateRows" {
  export default function validateRows(param: {rowsJson: any}): Promise<any>;
}
declare module "@salesforce/apex/BatchDeparturesUploadController.importDepartures" {
  export default function importDepartures(param: {rowsJson: any}): Promise<any>;
}
declare module "@salesforce/apex/BatchDeparturesUploadController.uploadDepartureDataWithBatch" {
  export default function uploadDepartureDataWithBatch(param: {recordJson: any, totalRecords: any, validatedRecords: any, failedValidationRecords: any, fileName: any, fileBase64: any, contentType: any}): Promise<any>;
}
