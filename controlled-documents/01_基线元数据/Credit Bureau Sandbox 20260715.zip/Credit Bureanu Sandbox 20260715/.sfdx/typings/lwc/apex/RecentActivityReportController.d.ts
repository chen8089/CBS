declare module "@salesforce/apex/RecentActivityReportController.getRecentActivities" {
  export default function getRecentActivities(param: {maxItems: any}): Promise<any>;
}
declare module "@salesforce/apex/RecentActivityReportController.getRecentActivitiesByRecordId" {
  export default function getRecentActivitiesByRecordId(param: {recordId: any, maxItems: any}): Promise<any>;
}
