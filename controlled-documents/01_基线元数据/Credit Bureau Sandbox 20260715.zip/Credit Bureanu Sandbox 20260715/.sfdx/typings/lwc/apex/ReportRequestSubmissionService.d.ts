declare module "@salesforce/apex/ReportRequestSubmissionService.submit" {
  export default function submit(param: {request: any}): Promise<any>;
}
