declare module "@salesforce/apex/BatchDeparturesDashboardController.getDepartureSummary" {
  export default function getDepartureSummary(): Promise<any>;
}
declare module "@salesforce/apex/BatchDeparturesDashboardController.getDepartures" {
  export default function getDepartures(param: {statusFilter: any, searchKey: any, sortBy: any, sortDirection: any, filters: any}): Promise<any>;
}
