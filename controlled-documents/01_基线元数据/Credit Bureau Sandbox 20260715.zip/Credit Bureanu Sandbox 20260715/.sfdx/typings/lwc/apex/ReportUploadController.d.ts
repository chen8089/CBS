declare module "@salesforce/apex/ReportUploadController.uploadReports" {
  export default function uploadReports(param: {rowsJson: any}): Promise<any>;
}
declare module "@salesforce/apex/ReportUploadController.uploadReportsWithBatch" {
  export default function uploadReportsWithBatch(param: {rowsJson: any, fileName: any, fileBase64: any, contentType: any}): Promise<any>;
}
