declare module "@salesforce/apex/RecentActivityDepartureController.getRecentActivities" {
  export default function getRecentActivities(param: {maxItems: any}): Promise<any>;
}
declare module "@salesforce/apex/RecentActivityDepartureController.getRecentActivitiesByRecordId" {
  export default function getRecentActivitiesByRecordId(param: {recordId: any, maxItems: any}): Promise<any>;
}
