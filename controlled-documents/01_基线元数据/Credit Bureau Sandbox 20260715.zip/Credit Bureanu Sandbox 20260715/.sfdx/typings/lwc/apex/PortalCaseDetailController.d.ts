declare module "@salesforce/apex/PortalCaseDetailController.getReportRequestItems" {
  export default function getReportRequestItems(param: {caseId: any}): Promise<any>;
}
