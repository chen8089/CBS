declare module "@salesforce/apex/ReportRequestExportService.exportAuthorizedList" {
  export default function exportAuthorizedList(param: {caseId: any, requestedFields: any}): Promise<any>;
}
declare module "@salesforce/apex/ReportRequestExportService.exportAuthorizedListForLatestBatch" {
  export default function exportAuthorizedListForLatestBatch(param: {requestedFields: any}): Promise<any>;
}
declare module "@salesforce/apex/ReportRequestExportService.exportAuthorizedListForLatestBatchNoTracking" {
  export default function exportAuthorizedListForLatestBatchNoTracking(param: {requestedFields: any}): Promise<any>;
}
