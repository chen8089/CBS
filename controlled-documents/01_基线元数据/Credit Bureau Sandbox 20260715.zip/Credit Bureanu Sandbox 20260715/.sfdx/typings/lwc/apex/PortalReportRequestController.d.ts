declare module "@salesforce/apex/PortalReportRequestController.getEligibleDataSubjects" {
  export default function getEligibleDataSubjects(param: {searchKey: any}): Promise<any>;
}
declare module "@salesforce/apex/PortalReportRequestController.createReportRequestCase" {
  export default function createReportRequestCase(param: {requestSubject: any, dataSubjectIds: any, slaDays: any}): Promise<any>;
}
