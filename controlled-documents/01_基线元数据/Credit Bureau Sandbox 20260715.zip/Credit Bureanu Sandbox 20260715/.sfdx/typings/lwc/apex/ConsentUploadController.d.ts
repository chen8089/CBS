declare module "@salesforce/apex/ConsentUploadController.validateAndUploadConsents" {
  export default function validateAndUploadConsents(param: {batchName: any, fileName: any, fileSizeBytes: any, rowsJson: any, headersJson: any, fileBodyBase64: any, fileMimeType: any}): Promise<any>;
}
declare module "@salesforce/apex/ConsentUploadController.uploadConsents" {
  export default function uploadConsents(param: {rowsJson: any}): Promise<any>;
}
