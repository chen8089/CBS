declare module "@salesforce/apex/DataSubjectConsentDashboardController.getConsentSummary" {
  export default function getConsentSummary(): Promise<any>;
}
declare module "@salesforce/apex/DataSubjectConsentDashboardController.getDataSubjects" {
  export default function getDataSubjects(param: {selectedCardValue: any, searchKey: any, sortBy: any, sortDirection: any, filters: any}): Promise<any>;
}
