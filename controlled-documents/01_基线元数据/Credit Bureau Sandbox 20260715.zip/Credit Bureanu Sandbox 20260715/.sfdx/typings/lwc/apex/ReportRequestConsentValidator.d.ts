declare module "@salesforce/apex/ReportRequestConsentValidator.validateForSubmission" {
  export default function validateForSubmission(param: {dataSubjectId: any, clientAccountId: any}): Promise<any>;
}
