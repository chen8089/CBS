declare module "@salesforce/resourceUrl/QRCodeJS" {
    var QRCodeJS: string;
    export default QRCodeJS;
}