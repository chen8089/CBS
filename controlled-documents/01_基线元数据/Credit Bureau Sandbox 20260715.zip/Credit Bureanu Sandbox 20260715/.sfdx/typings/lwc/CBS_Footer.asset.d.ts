declare module "@salesforce/contentAssetUrl/CBS_Footer" {
    var CBS_Footer: string;
    export default CBS_Footer;
}