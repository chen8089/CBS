declare module "@salesforce/resourceUrl/SNA_ASwXa_sf_default_cdn_PartnerCommunity2" {
    var SNA_ASwXa_sf_default_cdn_PartnerCommunity2: string;
    export default SNA_ASwXa_sf_default_cdn_PartnerCommunity2;
}