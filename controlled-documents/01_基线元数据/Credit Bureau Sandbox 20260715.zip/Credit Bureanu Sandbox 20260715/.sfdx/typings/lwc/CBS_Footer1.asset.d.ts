declare module "@salesforce/contentAssetUrl/CBS_Footer1" {
    var CBS_Footer1: string;
    export default CBS_Footer1;
}