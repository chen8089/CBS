declare module "@salesforce/label/c.CBS_Group_Mail_Recipients" {
    var CBS_Group_Mail_Recipients: string;
    export default CBS_Group_Mail_Recipients;
}
declare module "@salesforce/label/c.CBS_Guest_Site_Base_Url" {
    var CBS_Guest_Site_Base_Url: string;
    export default CBS_Guest_Site_Base_Url;
}
declare module "@salesforce/label/c.CBS_MyInfo_Api_Base_Url" {
    var CBS_MyInfo_Api_Base_Url: string;
    export default CBS_MyInfo_Api_Base_Url;
}
declare module "@salesforce/label/c.CBS_MyInfo_Basic_Auth_Password" {
    var CBS_MyInfo_Basic_Auth_Password: string;
    export default CBS_MyInfo_Basic_Auth_Password;
}
declare module "@salesforce/label/c.CBS_MyInfo_Basic_Auth_Username" {
    var CBS_MyInfo_Basic_Auth_Username: string;
    export default CBS_MyInfo_Basic_Auth_Username;
}
declare module "@salesforce/label/c.Singpass_Login_Config_Json" {
    var Singpass_Login_Config_Json: string;
    export default Singpass_Login_Config_Json;
}