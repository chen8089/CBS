declare module "@salesforce/resourceUrl/pagefoot" {
    var pagefoot: string;
    export default pagefoot;
}