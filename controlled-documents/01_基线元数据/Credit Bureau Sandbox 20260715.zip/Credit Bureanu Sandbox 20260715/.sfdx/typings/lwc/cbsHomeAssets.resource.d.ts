declare module "@salesforce/resourceUrl/cbsHomeAssets" {
    var cbsHomeAssets: string;
    export default cbsHomeAssets;
}